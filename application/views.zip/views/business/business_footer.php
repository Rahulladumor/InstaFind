<div class="page-footer">
                    <p class="no-s">2018 &copy; Insta Find.</p>
                </div>
            </div><!-- Page Inner -->
        </main><!-- Page Content -->
        <nav class="cd-nav-container" id="cd-nav">
            <header>
                <h3>Navigation</h3>
                <a href="#0" class="cd-close-nav">Close</a>
            </header>
            <ul class="cd-nav list-unstyled">
                <li class="cd-selected" data-menu="index">
                    <a href="javsacript:void(0);">
                        <span>
                            <i class="glyphicon glyphicon-home"></i>
                        </span>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li data-menu="profile">
                    <a href="javsacript:void(0);">
                        <span>
                            <i class="glyphicon glyphicon-user"></i>
                        </span>
                        <p>Profile</p>
                    </a>
                </li>
                <li data-menu="inbox">
                    <a href="javsacript:void(0);">
                        <span>
                            <i class="glyphicon glyphicon-envelope"></i>
                        </span>
                        <p>Mailbox</p>
                    </a>
                </li>
                <li data-menu="#">
                    <a href="javsacript:void(0);">
                        <span>
                            <i class="glyphicon glyphicon-tasks"></i>
                        </span>
                        <p>Tasks</p>
                    </a>
                </li>
                <li data-menu="#">
                    <a href="javsacript:void(0);">
                        <span>
                            <i class="glyphicon glyphicon-cog"></i>
                        </span>
                        <p>Settings</p>
                    </a>
                </li>
                <li data-menu="calendar">
                    <a href="javsacript:void(0);">
                        <span>
                            <i class="glyphicon glyphicon-calendar"></i>
                        </span>
                        <p>Calendar</p>
                    </a>
                </li>
            </ul>
        </nav>
        <div class="cd-overlay"></div>
	

        <!-- Javascripts -->
        <script src="<?php echo base_url();?>assets/business/assets/plugins/jquery/jquery-2.1.3.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/jquery-ui/jquery-ui.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/pace-master/pace.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/switchery/switchery.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/uniform/jquery.uniform.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/offcanvasmenueffects/js/classie.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/offcanvasmenueffects/js/main.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/waves/waves.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/3d-bold-navigation/js/main.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/jquery-mockjax-master/jquery.mockjax.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/datatables/js/jquery.datatables.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/js/pages/table-data.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/jquery-counterup/jquery.counterup.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/flot/jquery.flot.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/flot/jquery.flot.time.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/flot/jquery.flot.symbol.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/flot/jquery.flot.resize.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/flot/jquery.flot.tooltip.min.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/curvedlines/curvedLines.js"></script>
        <script src="<?php echo base_url();?>assets/business/assets/plugins/metrojs/MetroJs.min.js"></script>
        
        <script src="<?php echo base_url();?>assets/business/assets/js/modern.js"></script>

        <script src="<?php echo base_url();?>assets/business/assets/js/pages/dashboard.js"></script>     
    </body>
</html>