<?php $this->load->view('user/header'); ?>

<?php $this->load->view('user/center_contant'); ?>

<?php $this->load->view('user/footer'); ?>